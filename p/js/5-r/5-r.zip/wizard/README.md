# Multi Page Wizard Form Example

## To run locally

```
npm install
npm start
```

Then open [`http://localhost:3030/`](http://localhost:3030/).

* Troubleshooting: 
	* Install [NVM](https://github.com/creationix/nvm)
	* Switch to Node.js version specified in file .nvmrc and install dependencies:
		```
		nvm use
		npm install
		```